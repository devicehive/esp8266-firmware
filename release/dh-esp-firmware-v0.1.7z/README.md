# DeviceHive ESP8266 Firmware
This is binary images for DeviceHive ESP8266 Firmware. It contains simple
tools, examples and domentation for easy start of using this firmware.

# Usage
1. You need to connect ESP8266 to USB-TTL converter and connect to your
computer.
2. Install drivers for your USB-TTL converter.
3. Unpack this archive in dedicated dir. It has to contain at least 
0x00000.bin, 0x40000.bin, esp-flasher-<your OS>, esp-terminal-<your OS>
4. Switch ESP8266 to flash mode (connect GPIO0 to GND and reboot or power
up device)
5. Run esp-flasher-<your OS> without any args to start flashing procedure.
Util will automatically detect serial port and will use 0x00000.bin and
0x40000.bin images from current folder. You could can also use another
flasher, 'esptool' for example.
6. After flash complete, run esp-terminal-<your OS> to connect to serial
terminal on device. Util detects serial port automatically. You can also
use another serial terminal with escape sequences support, PuTTY or
'screen' for example.
7. Configure device with 'configure' command in terminal.
8. Now you can use this firmware!

# 0x00000.bin and 0x40000.bin
That is binary firmware images which supposed to be flash on ESP8266

# esp-flasher-win esp-flasher-linux esp-flasher-mac
Flasher util for corresponding OSs

# esp-terminal-win esp-terminal-linux esp-terminal-mac
Terminal util for corresponding OSs

# DeviceHiveESP8266commands.pdf
Document contains cloud commands specification for this firmware.

# examples
Sample of using JavaScript for sending/receiving commands from cloud. 

# Authors
Nikolay Khabarov
